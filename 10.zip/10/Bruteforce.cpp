﻿#include "Bruteforce.h"
#include "match.h"
#include <iostream>
#include <vector>
#include <string>
using namespace std; 

// Brute-force 
// Complexity: O((n - m + 1) * m)
/*static const long long BASE = 31;
static const long long MOD = 1000000009LL;
vector<int> brute_force_search(const string& text, const string& pattern) {
	vector <int> res; 
	int n = text.length(); 
	int m = pattern.length();
	if (m == 0 || m > n) return res;

	for (int i = 0; i <= n - m; i++) {
		int j = 0;			
		while (j < m && text[i + j] == pattern[j]) {
			if (text[i + j] != pattern[j]) break;
			j++;
		}
		if (j == m) {
			res.push_back(i); 
		}
	
	}
	return res; 
}
*/

void searchDirectionBF(const vector<vector<char>>& grid, const string& pat,
    int sr, int sc, int dr, int dc,
    vector<Match>& allMatches, long long& compCount) {

    int R = grid.size(), C = grid[0].size(), M = pat.length();
    int N = (dr == 0) ? C : R;

    for (int s = 0; s <= N - M; s++) {
        int j = 0;
        while (j < M) {
            compCount++;
            int r = sr + (s + j) * dr;
            int c = sc + (s + j) * dc;
            if (grid[r][c] != pat[j]) break;
            j++;
        }
        if (j == M) {
            int start_r = sr + s * dr;
            int start_c = sc + s * dc;
            int end_r = start_r + (M - 1) * dr;
            int end_c = start_c + (M - 1) * dc;
            allMatches.push_back({ start_r, start_c, end_r, end_c });
        }
    }
}

void searchMatrixBF(const vector<vector<char>>& grid, const string& pat,
    vector<Match>& allMatches, long long& compCount) {

    int R = grid.size(), C = grid[0].size(), M = pat.length();

    // Hàng
    if (M <= C) {
        for (int r = 0; r < R; r++)
            searchDirectionBF(grid, pat, r, 0, 0, 1, allMatches, compCount);
    }

    // Cột
    if (M <= R) {
        for (int c = 0; c < C; c++)
            searchDirectionBF(grid, pat, 0, c, 1, 0, allMatches, compCount);
    }
}