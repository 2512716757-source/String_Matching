﻿#ifndef RABINKARP_H
#define RABINKARP_H
#include <iostream>
#include <vector>
#include <string>
#include "match.h"
using namespace std;

void searchDirectionRK(const vector<vector<char>>& grid, const string& pat, int sr, int sc, int dr, int dc, vector<Match>& allMatches, long long& compCount);
void searchMatrixRK(const vector<vector<char>>& grid, const string& pat, vector<Match>& allMatches, long long& compCount);

#endif 
