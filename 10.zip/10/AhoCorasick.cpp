#include "AhoCorasick.h"
#include "match.h"
#include <queue>
#include <algorithm>

Node::Node() {
    fill(ch, ch + 26, -1);
    fail = 0;
}

void insert(vector<Node>& trie, const string& word, int index) {
    int cur = 0;
    for (char c : word) {
        int x = c - 'a';
        if (trie[cur].ch[x] == -1) {
            trie[cur].ch[x] = trie.size();
            trie.emplace_back();
        }
        cur = trie[cur].ch[x];
    }
    trie[cur].out.push_back(index);
}

void build(vector<Node>& trie) {
    queue<int> q;

    for (int c = 0; c < 26; c++) {
        int v = trie[0].ch[c];
        if (v == -1) trie[0].ch[c] = 0;
        else {
            trie[v].fail = 0;
            q.push(v);
        }
    }

    while (!q.empty()) {
        int u = q.front(); q.pop();

        for (int c = 0; c < 26; c++) {
            int v = trie[u].ch[c];

            if (v == -1) {
                trie[u].ch[c] = trie[trie[u].fail].ch[c];
            }
            else {
                trie[v].fail = trie[trie[u].fail].ch[c];

                // Merge output
                for (int x : trie[trie[v].fail].out)
                    trie[v].out.push_back(x);

                q.push(v);
            }
        }
    }
}

void multi_build(vector<Node>& trie, const vector<string>& keywords) {
    trie.clear();
    trie.emplace_back();

    for (int i = 0; i < (int)keywords.size(); i++)
        insert(trie, keywords[i], i);

    build(trie);
}

void ac_search_line(const string& text, const vector<Node>& trie, const vector<string>& keywords, vector<vector<int>>& res, long long& compCount) {

    int cur = 0;

    for (int i = 0; i < (int)text.size(); i++) {
        compCount++;
        cur = trie[cur].ch[text[i] - 'a'];

        for (int idx : trie[cur].out) {
            int start = i - (int)keywords[idx].size() + 1;
            res[idx].push_back(start);
        }
    }
}

void searchMatrixAC(const vector<vector<char>>& grid,
    const vector<string>& words,
    vector<vector<Match>>& allRes,
    long long& compCount) {

    int R = grid.size();
    int C = grid[0].size();

    vector<Node> trie;
    multi_build(trie, words); 

    for (int r = 0; r < R; r++) {
        string line;
        for (int c = 0; c < C; c++)
            line.push_back(grid[r][c]);

        vector<vector<int>> res(words.size());
        ac_search_line(line, trie, words, res, compCount);

        for (int wi = 0; wi < (int)words.size(); wi++) {
            int len = words[wi].size();
            for (int start : res[wi]) {
                allRes[wi].push_back({r, start, r, start + len - 1});
            }
        }
    }

    for (int c = 0; c < C; c++) {
        string line;
        for (int r = 0; r < R; r++)
            line.push_back(grid[r][c]);

        vector<vector<int>> res(words.size());
        ac_search_line(line, trie, words, res, compCount);

        for (int wi = 0; wi < (int)words.size(); wi++) {
            int len = words[wi].size();
            for (int start : res[wi]) {
                allRes[wi].push_back({start, c, start + len - 1, c});
            }
        }
    }
}