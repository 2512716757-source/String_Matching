========================================================================
           SORTING ALGORITHMS: ANALYSIS AND COMPARISON
========================================================================

1. PROJECT OVERVIEW
-------------------
This project is a comprehensive tool developed for executing, analyzing, 
and comparing various sorting algorithms. It supports multiple input 
data distributions and provides detailed performance metrics, including 
execution time (ms) and the total number of algorithmic comparisons.

2. FEATURES
-----------
* Algorithms Implemented: Selection Sort, Insertion Sort, Bubble Sort, 
  Shaker Sort, Shell Sort, Heap Sort, Merge Sort, Quick Sort, 
  Counting Sort, Radix Sort, and Flash Sort.
* Data Generation: Supports Random (-rand), Sorted (-sorted), 
  Reverse Sorted (-rev), and Nearly Sorted (-nsorted) data.
* Performance Measurement: Precise tracking of runtime (ms) 
  and algorithmic comparisons (comp).

3. PROJECT STRUCTURE
--------------------
The source code is organized into a modular architecture:

* Header Files (.h): 
  - On2.h, Onlogn.h, DataGenerator.h
* Source Files (.cpp):
  - main.cpp: Entry point; handles CLI arguments and execution flow.
  - O(n2).cpp: Implementations of O(n^2) average complexity algorithms 
  - O(nlogn).cpp: Implementations of O(nlogn) average complexity 
    algorithms.
  - O(n).cpp: Implementations of O(n) average complexitity algorithms.
  - DataGenerator.cpp: Utilities for creating test data distributions.

4. INSTALLATION & COMPILATION
-----------------------------
To build the project, ensure you have a C++ compiler (g++) installed. 
Navigate to the project directory and run the following command:

g++ *.cpp -std=c++14 -o groupID.exe

5. USAGE GUIDE
--------------
The program operates in two primary modes: 
Algorithm Mode (-a) and Comparison Mode (-c).

[ALGORITHM MODE]
* Command 1: Run a sort on an existing input file.
  ./10.exe -a [Algorithm] [Input_file] [Output_parameter]

* Command 2: Run a sort on generated data with a specific order.
  ./10.exe -a [Algorithm] [Input_size] [Input_order] [Output_parameter]

* Command 3: Run a sort on all data orders for a given size.
  ./10.exe -a [Algorithm] [Input_size] [Output_parameter]

[COMPARISON MODE]
* Command 4: Compare two algorithms on an existing input file.
  ./10.exe -c [Algorithm1] [Algorithm2] [Input_file]

* Command 5: Compare two algorithms on generated data.
  ./10.exe -c [Algorithm1] [Algorithm2] [Input_size] [Input_order]

[PARAMETERS]
* [Algorithm]: selection-sort, quick-sort, flash-sort, radix-sort, etc.
* [Input_order]: -rand, -nsorted, -sorted, -rev.
* [Output_parameter]: -time (Runtime), -comp (Comparisons), -both (Both).

6. CONTRIBUTORS
---------------
* [Đỗ Đăng Tú, Đỗ Minh Khang, Nguyễn Phúc Nguyên, Huỳnh Đình Khương].
* Developed as part of the Data Structures and Algorithms course in HCMUS.

========================================================================