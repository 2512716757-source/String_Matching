﻿#ifndef BRUTEFORCE_H
#define BRUTEFORCE_H
#include <iostream>
#include <vector>
#include <string>
#include "match.h"
using namespace std;

void searchDirectionBF(const vector<vector<char>>& grid, const string& pat, int sr, int sc, int dr, int dc, vector<Match>& allMatches, long long& compCount);
void searchMatrixBF(const vector<vector<char>>& grid, const string& pat, vector<Match>& allMatches, long long& compCount);
#endif 
