﻿#ifndef AHO_CORASICK_H
#define AHO_CORASICK_H
#include <string>
#include <vector>
#include "match.h"
using namespace std;

struct Node {
    int ch[256];
    int fail;
    vector<int> out;
    Node();
};

void insert(vector<Node>& trie, const string& word, int index);
void build(vector<Node>& trie);
void multi_build(vector<Node>& trie, const vector<string>& keywords);
void ac_search_line(const string& text, const vector<Node>& trie, const vector<string>& keywords, vector<vector<int>>& res, long long& compCount);
void searchMatrixAC(const vector<vector<char>>& grid, const vector<string>& words, vector<vector<Match>>& allRes, long long& compCount);

#endif