﻿#include "RabinKarp.h"
#include "match.h"
#include <iostream>
#include <vector>
#include <string>

static const long long BASE = 31;
static const long long MOD = 1000000009LL;

//  Rabin-Karp
//  Using Rolling Hash
//  Base = 31, Mod = 1e9+9  
//  Complexity: O(n+m) for average case and O(n*m) for worst case (many collision).
/*vector<int> Rabin_Karp_search(const string& text, const string& pattern) {
	vector<int> res;
	int n = text.size();
	int m = pattern.size();

	if (m == 0 || m > n) return res;

	long long hash_pattern = 0;
	long long hash_text = 0;
	long long power = 1;
	for (int i = 0; i < m - 1; i++) {
		power = power * BASE % MOD;
	}

	for (int i = 0; i < m; i++) {
		hash_pattern = (hash_pattern * BASE + (pattern[i] - 'a' + 1)) % MOD;
		hash_text = (hash_text * BASE + (text[i] - 'a' + 1)) % MOD;
	}

	for (int i = 0; i <= n - m; ++i) {
		if (hash_pattern == hash_text) { // check
			bool check = true;
			for (int j = 0; j < m; ++j) {
				++comparisons;
				if (text[i + j] != pattern[j]) {
					check = false;
					break;
				}
			}
			if (check) res.push_back(i);
		}
		// Update the rolling hash for next window
		if (i < n - m) {
			hash_text = (hash_text - (long long)(text[i] - 'a' + 1) * power % MOD + MOD) % MOD;
			hash_text = (hash_text * BASE + (text[i + m] - 'a' + 1)) % MOD;
		}
	}
	return res;
}
*/

void searchDirectionRK(const vector<vector<char>>& grid, const string& pat,
    int sr, int sc, int dr, int dc,
    vector<Match>& allMatches, long long& compCount) {

    int R = grid.size(), C = grid[0].size();
    int M = pat.length();
    int N = (dr == 0) ? C : R;

    if (M > N) return;

    long long hash_pat = 0, hash_txt = 0, power = 1;

    for (int i = 0; i < M - 1; i++) power = (power * BASE) % MOD;

    for (int i = 0; i < M; i++) {
        hash_pat = (hash_pat * BASE + (pat[i] - 'a' + 1)) % MOD;
        int r = sr + i * dr;
        int c = sc + i * dc;
        hash_txt = (hash_txt * BASE + (grid[r][c] - 'a' + 1)) % MOD;
    }

    for (int s = 0; s <= N - M; s++) {
        if (hash_pat == hash_txt) {
            bool ok = true;
            for (int j = 0; j < M; j++) {
                compCount++;
                int r = sr + (s + j) * dr;
                int c = sc + (s + j) * dc;
                if (grid[r][c] != pat[j]) { ok = false; break; }
            }
            if (ok) {
                int sr1 = sr + s * dr;
                int sc1 = sc + s * dc;
                int er = sr1 + (M - 1) * dr;
                int ec = sc1 + (M - 1) * dc;
                allMatches.push_back({ sr1, sc1, er, ec });
            }
        }

        if (s < N - M) {
            int r1 = sr + s * dr;
            int c1 = sc + s * dc;
            int r2 = sr + (s + M) * dr;
            int c2 = sc + (s + M) * dc;

            hash_txt = (hash_txt - (grid[r1][c1] - 'a' + 1) * power % MOD + MOD) % MOD;
            hash_txt = (hash_txt * BASE + (grid[r2][c2] - 'a' + 1)) % MOD;
        }
    }
}

void searchMatrixRK(const vector<vector<char>>& grid, const string& pat,
    vector<Match>& allMatches, long long& compCount) {

    int R = grid.size(), C = grid[0].size(), M = pat.length();

    if (M <= C)
        for (int r = 0; r < R; r++)
            searchDirectionRK(grid, pat, r, 0, 0, 1, allMatches, compCount);

    if (M <= R)
        for (int c = 0; c < C; c++)
            searchDirectionRK(grid, pat, 0, c, 1, 0, allMatches, compCount);
}