#ifndef AHO_CORASICK
#define AHO_CORASICK
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <algorithm>
#include "match.h"
using namespace std; 

/*struct Node {
	int ch[26]; 
	int fail; // failure link
	int out; 
	Node();
};


void insert(vector<Node>& trie, const string& word, int idx);
void build(vector<Node>& trie);
map<int, vector<int>> ac_search(const string& text, const vector<string>& keywords);*/

struct Node {
    int ch[26];
    int fail;
    vector<int> out; 

    Node();
};

void insert(vector<Node>& trie, const string& word, int index);
void build(vector<Node>& trie); 
void multi_build(vector<Node>& trie, const vector<string>& keywords);

void ac_search_line(const string& text, const vector<Node>& trie, const vector<string>& keywords, map<int, vector<int>>& res, long long& compCount);

void searchMatrixAC(const vector<vector<char>>& grid, const vector<string>& words, vector<vector<Match>>& allRes, long long& compCount);



#endif 
